<template>
  <div class="min-h-screen bg-gradient-to-br from-primary-50 to-secondary-50 dark:from-secondary-900 dark:to-secondary-800">
    <!-- Header -->
    <div class="bg-white/80 dark:bg-secondary-800/80 backdrop-blur-md border-b border-secondary-200 dark:border-secondary-700">
      <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div class="flex items-center space-x-4">
          <button @click="goBack" class="p-2 text-secondary-600 dark:text-secondary-400 hover:text-secondary-900 dark:hover:text-white transition-colors duration-200">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
            </svg>
          </button>
          <div>
            <h1 class="text-3xl font-bold text-secondary-900 dark:text-white">Cookie Policy</h1>
            <p class="text-secondary-600 dark:text-secondary-400 mt-2">Last updated: {{ lastUpdated }}</p>
          </div>
        </div>
      </div>
    </div>

    <!-- Main Content -->
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div class="bg-white/80 dark:bg-secondary-800/80 backdrop-blur-md rounded-2xl p-8 border border-white/20 dark:border-secondary-700/20">
        
        <!-- Introduction -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">1. What Are Cookies?</h2>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed mb-4">
            Cookies are small text files that are stored on your device (computer, tablet, or mobile phone) when you visit our website. They help us provide you with a better experience by remembering your preferences and enabling certain functionality.
          </p>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed">
            CarWise.ai uses cookies and similar technologies to enhance your experience, analyze usage patterns, and provide personalized services. This Cookie Policy explains how we use these technologies and your choices regarding them.
          </p>
        </section>

        <!-- Types of Cookies -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">2. Types of Cookies We Use</h2>
          
          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">2.1 Essential Cookies</h3>
          <div class="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-700 rounded-lg p-4 mb-4">
            <p class="text-green-800 dark:text-green-200 font-medium mb-2">
              <strong>Purpose:</strong> These cookies are necessary for the website to function properly and cannot be disabled.
            </p>
            <ul class="list-disc list-inside text-green-700 dark:text-green-300 space-y-1">
              <li>Authentication and login sessions</li>
              <li>Security and fraud prevention</li>
              <li>Load balancing and performance</li>
              <li>Remembering your language and currency preferences</li>
            </ul>
          </div>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">2.2 Functional Cookies</h3>
          <div class="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-700 rounded-lg p-4 mb-4">
            <p class="text-blue-800 dark:text-blue-200 font-medium mb-2">
              <strong>Purpose:</strong> These cookies enhance functionality and personalization.
            </p>
            <ul class="list-disc list-inside text-blue-700 dark:text-blue-300 space-y-1">
              <li>Remembering your dashboard preferences</li>
              <li>Storing your vehicle information</li>
              <li>Maintaining your diagnosis history</li>
              <li>Dark/light mode preferences</li>
            </ul>
          </div>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">2.3 Analytics Cookies</h3>
          <div class="bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-700 rounded-lg p-4 mb-4">
            <p class="text-purple-800 dark:text-purple-200 font-medium mb-2">
              <strong>Purpose:</strong> These cookies help us understand how you use our website.
            </p>
            <ul class="list-disc list-inside text-purple-700 dark:text-purple-300 space-y-1">
              <li>Page views and user interactions</li>
              <li>Feature usage statistics</li>
              <li>Performance monitoring</li>
              <li>Error tracking and debugging</li>
            </ul>
          </div>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">2.4 Marketing Cookies</h3>
          <div class="bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-700 rounded-lg p-4">
            <p class="text-orange-800 dark:text-orange-200 font-medium mb-2">
              <strong>Purpose:</strong> These cookies are used to deliver relevant advertisements and marketing content.
            </p>
            <ul class="list-disc list-inside text-orange-700 dark:text-orange-300 space-y-1">
              <li>Personalized advertisements</li>
              <li>Social media integration</li>
              <li>Email marketing campaigns</li>
              <li>Conversion tracking</li>
            </ul>
          </div>
        </section>

        <!-- Specific Cookies Used -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">3. Specific Cookies We Use</h2>
          
          <div class="overflow-x-auto">
            <table class="w-full border-collapse border border-secondary-200 dark:border-secondary-700 rounded-lg">
              <thead>
                <tr class="bg-secondary-50 dark:bg-secondary-700">
                  <th class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-left text-sm font-medium text-secondary-900 dark:text-white">Cookie Name</th>
                  <th class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-left text-sm font-medium text-secondary-900 dark:text-white">Purpose</th>
                  <th class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-left text-sm font-medium text-secondary-900 dark:text-white">Duration</th>
                  <th class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-left text-sm font-medium text-secondary-900 dark:text-white">Type</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">carwise_session</td>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">Maintains your login session</td>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">Session</td>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">Essential</td>
                </tr>
                <tr>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">carwise_token</td>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">Authentication token</td>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">30 days</td>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">Essential</td>
                </tr>
                <tr>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">carwise_language</td>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">Stores your language preference</td>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">1 year</td>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">Functional</td>
                </tr>
                <tr>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">carwise_currency</td>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">Stores your currency preference</td>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">1 year</td>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">Functional</td>
                </tr>
                <tr>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">carwise_theme</td>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">Dark/light mode preference</td>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">1 year</td>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">Functional</td>
                </tr>
                <tr>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">_ga</td>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">Google Analytics - user identification</td>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">2 years</td>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">Analytics</td>
                </tr>
                <tr>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">_gid</td>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">Google Analytics - session identification</td>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">24 hours</td>
                  <td class="border border-secondary-200 dark:border-secondary-700 px-4 py-3 text-sm text-secondary-700 dark:text-secondary-300">Analytics</td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>

        <!-- Third-Party Cookies -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">4. Third-Party Cookies</h2>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed mb-4">
            We may use third-party services that set their own cookies. These services include:
          </p>
          
          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">4.1 Analytics Services</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2 mb-4">
            <li><strong>Google Analytics:</strong> Tracks website usage and performance</li>
            <li><strong>Hotjar:</strong> Records user interactions for UX improvement</li>
            <li><strong>Mixpanel:</strong> Event tracking and user behavior analysis</li>
          </ul>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">4.2 AI Service Providers</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2 mb-4">
            <li><strong>OpenAI:</strong> May set cookies for API usage tracking</li>
            <li><strong>Google Gemini:</strong> May set cookies for service optimization</li>
            <li><strong>Anthropic Claude:</strong> May set cookies for usage analytics</li>
          </ul>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">4.3 Social Media and Marketing</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2">
            <li><strong>Facebook Pixel:</strong> Tracks conversions and ad performance</li>
            <li><strong>Google Ads:</strong> Tracks advertising effectiveness</li>
            <li><strong>LinkedIn Insight:</strong> Professional network integration</li>
          </ul>
        </section>

        <!-- Cookie Management -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">5. Managing Your Cookie Preferences</h2>
          
          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">5.1 Cookie Consent Banner</h3>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed mb-4">
            When you first visit our website, you'll see a cookie consent banner. You can:
          </p>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2 mb-4">
            <li>Accept all cookies</li>
            <li>Reject non-essential cookies</li>
            <li>Customize your preferences</li>
            <li>Learn more about each cookie type</li>
          </ul>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">5.2 Browser Settings</h3>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed mb-4">
            You can also manage cookies through your browser settings:
          </p>
          
          <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div class="bg-secondary-50 dark:bg-secondary-700/50 rounded-lg p-4">
              <h4 class="font-medium text-secondary-900 dark:text-white mb-2">Chrome</h4>
              <p class="text-sm text-secondary-700 dark:text-secondary-300">Settings → Privacy and Security → Cookies and other site data</p>
            </div>
            <div class="bg-secondary-50 dark:bg-secondary-700/50 rounded-lg p-4">
              <h4 class="font-medium text-secondary-900 dark:text-white mb-2">Firefox</h4>
              <p class="text-sm text-secondary-700 dark:text-secondary-300">Options → Privacy & Security → Cookies and Site Data</p>
            </div>
            <div class="bg-secondary-50 dark:bg-secondary-700/50 rounded-lg p-4">
              <h4 class="font-medium text-secondary-900 dark:text-white mb-2">Safari</h4>
              <p class="text-sm text-secondary-700 dark:text-secondary-300">Preferences → Privacy → Manage Website Data</p>
            </div>
            <div class="bg-secondary-50 dark:bg-secondary-700/50 rounded-lg p-4">
              <h4 class="font-medium text-secondary-900 dark:text-white mb-2">Edge</h4>
              <p class="text-sm text-secondary-700 dark:text-secondary-300">Settings → Cookies and site permissions → Cookies and site data</p>
            </div>
          </div>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">5.3 Account Settings</h3>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed">
            You can also manage your cookie preferences through your CarWise.ai account settings, where you can:
          </p>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2 mt-2">
            <li>Update your privacy preferences</li>
            <li>Control marketing communications</li>
            <li>Manage data sharing settings</li>
            <li>Export or delete your data</li>
          </ul>
        </section>

        <!-- Impact of Disabling Cookies -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">6. Impact of Disabling Cookies</h2>
          
          <div class="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-700 rounded-lg p-4 mb-4">
            <p class="text-yellow-800 dark:text-yellow-200 font-medium mb-2">
              <strong>Important:</strong> Disabling certain cookies may affect your experience on our website.
            </p>
          </div>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">6.1 Essential Cookies</h3>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed mb-4">
            If you disable essential cookies, you may not be able to:
          </p>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2 mb-4">
            <li>Log into your account</li>
            <li>Access secure areas of the website</li>
            <li>Complete transactions</li>
            <li>Use core functionality</li>
          </ul>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">6.2 Functional Cookies</h3>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed mb-4">
            Disabling functional cookies may result in:
          </p>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2 mb-4">
            <li>Loss of personalized settings</li>
            <li>Need to re-enter preferences each visit</li>
            <li>Reduced user experience</li>
            <li>Inability to save vehicle information</li>
          </ul>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">6.3 Analytics Cookies</h3>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed">
            Disabling analytics cookies means:
          </p>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2">
            <li>We cannot improve our services based on usage data</li>
            <li>Performance issues may not be detected</li>
            <li>Personalized recommendations may be less accurate</li>
          </ul>
        </section>

        <!-- Data Protection -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">7. Data Protection and Security</h2>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed mb-4">
            We take the security of your data seriously. Our cookie practices include:
          </p>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2">
            <li>Encryption of sensitive cookie data</li>
            <li>Regular security audits and updates</li>
            <li>Compliance with data protection regulations</li>
            <li>Secure transmission of cookie data</li>
            <li>Limited data retention periods</li>
          </ul>
        </section>

        <!-- Updates to Policy -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">8. Updates to This Cookie Policy</h2>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed">
            We may update this Cookie Policy from time to time to reflect changes in our practices or for other operational, legal, or regulatory reasons. We will notify you of any material changes by posting the updated policy on our website and updating the "Last updated" date.
          </p>
        </section>

        <!-- Contact Information -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">9. Contact Us</h2>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed mb-4">
            If you have any questions about our use of cookies or this Cookie Policy, please contact us:
          </p>
          <div class="bg-secondary-50 dark:bg-secondary-700/50 rounded-lg p-4">
            <p class="text-secondary-700 dark:text-secondary-300"><strong>Email:</strong> privacy@carwise.ai</p>
            <p class="text-secondary-700 dark:text-secondary-300"><strong>Address:</strong> CarWise.ai Privacy Team, [Your Business Address]</p>
            <p class="text-secondary-700 dark:text-secondary-300"><strong>Phone:</strong> [Your Contact Number]</p>
          </div>
        </section>

        <!-- Legal Compliance -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">10. Legal Compliance</h2>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed mb-4">
            This Cookie Policy is designed to comply with applicable laws and regulations, including:
          </p>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2">
            <li>General Data Protection Regulation (GDPR) - European Union</li>
            <li>ePrivacy Directive (Cookie Law) - European Union</li>
            <li>California Consumer Privacy Act (CCPA) - California, USA</li>
            <li>Personal Information Protection and Electronic Documents Act (PIPEDA) - Canada</li>
            <li>Privacy Act 1988 - Australia</li>
            <li>Data Protection Act 2018 - United Kingdom</li>
          </ul>
        </section>

      </div>
    </div>
  </div>
</template>

<script>
import { useRouter } from 'vue-router'

export default {
  name: 'CookiePolicy',
  setup() {
    const router = useRouter()
    const lastUpdated = 'December 2024'

    const goBack = () => {
      router.go(-1)
    }

    return {
      lastUpdated,
      goBack
    }
  }
}
</script>
