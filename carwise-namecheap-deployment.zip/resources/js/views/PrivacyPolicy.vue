<template>
  <div class="min-h-screen bg-gradient-to-br from-primary-50 to-secondary-50 dark:from-secondary-900 dark:to-secondary-800">
    <!-- Header -->
    <div class="bg-white/80 dark:bg-secondary-800/80 backdrop-blur-md border-b border-secondary-200 dark:border-secondary-700">
      <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div class="flex items-center space-x-4">
          <button @click="goBack" class="p-2 text-secondary-600 dark:text-secondary-400 hover:text-secondary-900 dark:hover:text-white transition-colors duration-200">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
            </svg>
          </button>
          <div>
            <h1 class="text-3xl font-bold text-secondary-900 dark:text-white">Privacy Policy</h1>
            <p class="text-secondary-600 dark:text-secondary-400 mt-2">Last updated: {{ lastUpdated }}</p>
          </div>
        </div>
      </div>
    </div>

    <!-- Main Content -->
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div class="bg-white/80 dark:bg-secondary-800/80 backdrop-blur-md rounded-2xl p-8 border border-white/20 dark:border-secondary-700/20">
        
        <!-- Introduction -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">1. Introduction</h2>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed mb-4">
            CarWise.ai ("we," "our," or "us") is committed to protecting your privacy and personal information. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our AI-powered car diagnosis platform and related services.
          </p>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed">
            By using our services, you consent to the data practices described in this policy. If you do not agree with our policies and practices, please do not use our services.
          </p>
        </section>

        <!-- Information We Collect -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">2. Information We Collect</h2>
          
          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">2.1 Personal Information</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2 mb-4">
            <li><strong>Account Information:</strong> Name, email address, phone number, and password</li>
            <li><strong>Profile Information:</strong> Location, preferences, and role (car owner or mechanic)</li>
            <li><strong>Vehicle Information:</strong> Car make, model, year, VIN, license plate, and specifications</li>
            <li><strong>Diagnosis Data:</strong> Problem descriptions, symptoms, and diagnostic results</li>
            <li><strong>Communication Data:</strong> Messages, feedback, and support requests</li>
          </ul>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">2.2 Technical Information</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2 mb-4">
            <li><strong>Device Information:</strong> IP address, browser type, operating system, and device identifiers</li>
            <li><strong>Usage Data:</strong> Pages visited, features used, time spent, and interaction patterns</li>
            <li><strong>Cookies and Tracking:</strong> Session data, preferences, and analytics information</li>
            <li><strong>Location Data:</strong> Approximate location based on IP address (if permitted)</li>
          </ul>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">2.3 AI Processing Data</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2">
            <li><strong>Diagnostic Inputs:</strong> Vehicle symptoms, descriptions, and uploaded media</li>
            <li><strong>AI Responses:</strong> Generated diagnoses, recommendations, and insights</li>
            <li><strong>Processing Metadata:</strong> AI provider used, processing time, and confidence scores</li>
          </ul>
        </section>

        <!-- How We Use Information -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">3. How We Use Your Information</h2>
          
          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">3.1 Service Provision</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2 mb-4">
            <li>Provide AI-powered car diagnosis and recommendations</li>
            <li>Maintain and improve our platform functionality</li>
            <li>Process payments and manage subscriptions</li>
            <li>Connect users with certified mechanics</li>
            <li>Provide customer support and technical assistance</li>
          </ul>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">3.2 AI and Machine Learning</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2 mb-4">
            <li>Train and improve our AI models for better diagnosis accuracy</li>
            <li>Analyze patterns to enhance diagnostic capabilities</li>
            <li>Generate personalized recommendations and insights</li>
            <li>Develop new features and services</li>
          </ul>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">3.3 Communication and Marketing</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2">
            <li>Send service-related notifications and updates</li>
            <li>Provide diagnostic results and follow-up recommendations</li>
            <li>Send marketing communications (with your consent)</li>
            <li>Conduct surveys and gather feedback</li>
          </ul>
        </section>

        <!-- Information Sharing -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">4. Information Sharing and Disclosure</h2>
          
          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">4.1 Third-Party AI Providers</h3>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed mb-4">
            We may share diagnostic data with third-party AI providers (OpenAI, Google Gemini, Anthropic Claude, etc.) to process your diagnosis requests. These providers have their own privacy policies and data practices.
          </p>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">4.2 Service Providers</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2 mb-4">
            <li>Cloud hosting and storage providers</li>
            <li>Payment processors and financial institutions</li>
            <li>Analytics and monitoring services</li>
            <li>Customer support and communication tools</li>
          </ul>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">4.3 Legal Requirements</h3>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed">
            We may disclose your information if required by law, court order, or to protect our rights, property, or safety, or that of our users or the public.
          </p>
        </section>

        <!-- Data Security -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">5. Data Security</h2>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed mb-4">
            We implement appropriate technical and organizational measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction. These measures include:
          </p>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2">
            <li>Encryption of data in transit and at rest</li>
            <li>Regular security assessments and updates</li>
            <li>Access controls and authentication mechanisms</li>
            <li>Secure data centers and infrastructure</li>
            <li>Employee training on data protection</li>
          </ul>
        </section>

        <!-- Your Rights -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">6. Your Rights and Choices</h2>
          
          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">6.1 Access and Control</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2 mb-4">
            <li><strong>Access:</strong> Request a copy of your personal information</li>
            <li><strong>Correction:</strong> Update or correct inaccurate information</li>
            <li><strong>Deletion:</strong> Request deletion of your personal information</li>
            <li><strong>Portability:</strong> Export your data in a machine-readable format</li>
            <li><strong>Restriction:</strong> Limit how we process your information</li>
          </ul>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">6.2 Communication Preferences</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2">
            <li>Opt-out of marketing communications</li>
            <li>Manage notification preferences</li>
            <li>Control cookie settings</li>
            <li>Update privacy settings in your account</li>
          </ul>
        </section>

        <!-- International Transfers -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">7. International Data Transfers</h2>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed">
            Your information may be transferred to and processed in countries other than your own. We ensure appropriate safeguards are in place for such transfers, including standard contractual clauses and adequacy decisions under applicable data protection laws.
          </p>
        </section>

        <!-- Data Retention -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">8. Data Retention</h2>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed mb-4">
            We retain your personal information for as long as necessary to provide our services and fulfill the purposes outlined in this policy. Specific retention periods include:
          </p>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2">
            <li><strong>Account Data:</strong> Until account deletion or 3 years of inactivity</li>
            <li><strong>Diagnostic Data:</strong> 7 years for service improvement and legal compliance</li>
            <li><strong>Communication Data:</strong> 2 years from last interaction</li>
            <li><strong>Technical Data:</strong> 1 year for analytics and security purposes</li>
          </ul>
        </section>

        <!-- Children's Privacy -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">9. Children's Privacy</h2>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed">
            Our services are not intended for children under 16 years of age. We do not knowingly collect personal information from children under 16. If we become aware that we have collected such information, we will take steps to delete it promptly.
          </p>
        </section>

        <!-- Changes to Policy -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">10. Changes to This Privacy Policy</h2>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed">
            We may update this Privacy Policy from time to time. We will notify you of any material changes by posting the new policy on our website and updating the "Last updated" date. Your continued use of our services after such changes constitutes acceptance of the updated policy.
          </p>
        </section>

        <!-- Contact Information -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">11. Contact Us</h2>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed mb-4">
            If you have any questions about this Privacy Policy or our data practices, please contact us:
          </p>
          <div class="bg-secondary-50 dark:bg-secondary-700/50 rounded-lg p-4">
            <p class="text-secondary-700 dark:text-secondary-300"><strong>Email:</strong> privacy@carwise.ai</p>
            <p class="text-secondary-700 dark:text-secondary-300"><strong>Address:</strong> CarWise.ai Privacy Team, [Your Business Address]</p>
            <p class="text-secondary-700 dark:text-secondary-300"><strong>Phone:</strong> [Your Contact Number]</p>
          </div>
        </section>

        <!-- Compliance -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">12. Regulatory Compliance</h2>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed mb-4">
            This Privacy Policy is designed to comply with applicable data protection laws, including:
          </p>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2">
            <li>General Data Protection Regulation (GDPR) - European Union</li>
            <li>California Consumer Privacy Act (CCPA) - California, USA</li>
            <li>Personal Information Protection and Electronic Documents Act (PIPEDA) - Canada</li>
            <li>Privacy Act 1988 - Australia</li>
            <li>Data Protection Act 2018 - United Kingdom</li>
          </ul>
        </section>

      </div>
    </div>
  </div>
</template>

<script>
import { useRouter } from 'vue-router'

export default {
  name: 'PrivacyPolicy',
  setup() {
    const router = useRouter()
    const lastUpdated = 'December 2024'

    const goBack = () => {
      router.go(-1)
    }

    return {
      lastUpdated,
      goBack
    }
  }
}
</script>
