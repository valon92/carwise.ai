<template>
  <div class="min-h-screen bg-gradient-to-br from-primary-50 to-secondary-50 dark:from-secondary-900 dark:to-secondary-800">
    <!-- Header -->
    <div class="bg-white/80 dark:bg-secondary-800/80 backdrop-blur-md border-b border-secondary-200 dark:border-secondary-700">
      <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div class="flex items-center space-x-4">
          <button @click="goBack" class="p-2 text-secondary-600 dark:text-secondary-400 hover:text-secondary-900 dark:hover:text-white transition-colors duration-200">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"></path>
            </svg>
          </button>
          <div>
            <h1 class="text-3xl font-bold text-secondary-900 dark:text-white">Terms of Service</h1>
            <p class="text-secondary-600 dark:text-secondary-400 mt-2">Last updated: {{ lastUpdated }}</p>
          </div>
        </div>
      </div>
    </div>

    <!-- Main Content -->
    <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div class="bg-white/80 dark:bg-secondary-800/80 backdrop-blur-md rounded-2xl p-8 border border-white/20 dark:border-secondary-700/20">
        
        <!-- Introduction -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">1. Agreement to Terms</h2>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed mb-4">
            These Terms of Service ("Terms") constitute a legally binding agreement between you and CarWise.ai ("Company," "we," "our," or "us") regarding your use of our AI-powered car diagnosis platform and related services (collectively, the "Service").
          </p>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed">
            By accessing or using our Service, you agree to be bound by these Terms. If you disagree with any part of these terms, you may not access the Service.
          </p>
        </section>

        <!-- Service Description -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">2. Service Description</h2>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed mb-4">
            CarWise.ai provides an AI-powered platform that offers:
          </p>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2 mb-4">
            <li>Automated car diagnosis using artificial intelligence</li>
            <li>Vehicle maintenance recommendations and insights</li>
            <li>Connection with certified mechanics and service providers</li>
            <li>Vehicle management and history tracking</li>
            <li>Multi-language support and currency conversion</li>
            <li>Educational resources about automotive care</li>
          </ul>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed">
            <strong>Important:</strong> Our AI diagnosis is for informational purposes only and should not replace professional mechanical inspection or repair services.
          </p>
        </section>

        <!-- User Accounts -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">3. User Accounts and Registration</h2>
          
          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">3.1 Account Creation</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2 mb-4">
            <li>You must provide accurate, current, and complete information during registration</li>
            <li>You are responsible for maintaining the confidentiality of your account credentials</li>
            <li>You must be at least 16 years old to create an account</li>
            <li>One person or entity may not maintain multiple accounts</li>
          </ul>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">3.2 Account Responsibilities</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2">
            <li>Notify us immediately of any unauthorized use of your account</li>
            <li>You are responsible for all activities that occur under your account</li>
            <li>We reserve the right to suspend or terminate accounts that violate these Terms</li>
          </ul>
        </section>

        <!-- Acceptable Use -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">4. Acceptable Use Policy</h2>
          
          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">4.1 Permitted Uses</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2 mb-4">
            <li>Use the Service for legitimate automotive diagnosis and maintenance purposes</li>
            <li>Provide accurate and truthful information about your vehicles</li>
            <li>Respect other users and maintain professional communication</li>
            <li>Comply with all applicable laws and regulations</li>
          </ul>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">4.2 Prohibited Uses</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2 mb-4">
            <li>Use the Service for any unlawful purpose or in violation of any applicable laws</li>
            <li>Attempt to gain unauthorized access to our systems or other users' accounts</li>
            <li>Interfere with or disrupt the Service or servers connected to the Service</li>
            <li>Upload malicious code, viruses, or other harmful content</li>
            <li>Impersonate another person or entity</li>
            <li>Use the Service to compete with us or for commercial purposes without permission</li>
            <li>Reverse engineer, decompile, or disassemble any part of the Service</li>
            <li>Provide false, misleading, or fraudulent information</li>
          </ul>
        </section>

        <!-- AI Services and Limitations -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">5. AI Services and Limitations</h2>
          
          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">5.1 AI Diagnosis Disclaimer</h3>
          <div class="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-700 rounded-lg p-4 mb-4">
            <p class="text-yellow-800 dark:text-yellow-200 font-medium">
              <strong>Important Disclaimer:</strong> Our AI diagnosis is provided for informational purposes only and should not be considered as professional mechanical advice, diagnosis, or treatment.
            </p>
          </div>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2 mb-4">
            <li>AI results are based on patterns and may not be 100% accurate</li>
            <li>Always consult with qualified mechanics for critical safety issues</li>
            <li>We do not guarantee the accuracy, completeness, or reliability of AI diagnoses</li>
            <li>Users assume full responsibility for decisions based on AI recommendations</li>
          </ul>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">5.2 Third-Party AI Providers</h3>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed">
            We may use third-party AI services (OpenAI, Google Gemini, Anthropic Claude, etc.) to provide diagnosis capabilities. These services are subject to their own terms and limitations.
          </p>
        </section>

        <!-- Intellectual Property -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">6. Intellectual Property Rights</h2>
          
          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">6.1 Our Intellectual Property</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2 mb-4">
            <li>The Service and its original content, features, and functionality are owned by CarWise.ai</li>
            <li>Our trademarks, logos, and brand elements are protected intellectual property</li>
            <li>You may not use our intellectual property without written permission</li>
          </ul>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">6.2 User Content</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2">
            <li>You retain ownership of content you upload to the Service</li>
            <li>You grant us a license to use your content to provide and improve our services</li>
            <li>You represent that you have the right to share any content you upload</li>
          </ul>
        </section>

        <!-- Payment Terms -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">7. Payment Terms</h2>
          
          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">7.1 Subscription Services</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2 mb-4">
            <li>Some features may require paid subscriptions</li>
            <li>Subscription fees are billed in advance on a recurring basis</li>
            <li>Prices are subject to change with 30 days' notice</li>
            <li>All fees are non-refundable unless otherwise specified</li>
          </ul>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">7.2 Payment Processing</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2">
            <li>We use third-party payment processors for secure transactions</li>
            <li>You are responsible for all applicable taxes</li>
            <li>Failed payments may result in service suspension</li>
            <li>Refunds are processed according to our refund policy</li>
          </ul>
        </section>

        <!-- Privacy and Data -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">8. Privacy and Data Protection</h2>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed mb-4">
            Your privacy is important to us. Our collection and use of personal information is governed by our Privacy Policy, which is incorporated into these Terms by reference.
          </p>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2">
            <li>We collect and process data as described in our Privacy Policy</li>
            <li>You have rights regarding your personal information</li>
            <li>We implement appropriate security measures to protect your data</li>
            <li>We comply with applicable data protection laws</li>
          </ul>
        </section>

        <!-- Service Availability -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">9. Service Availability and Modifications</h2>
          
          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">9.1 Service Availability</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2 mb-4">
            <li>We strive to maintain high service availability but cannot guarantee 100% uptime</li>
            <li>Scheduled maintenance will be announced in advance when possible</li>
            <li>We are not liable for service interruptions or downtime</li>
          </ul>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">9.2 Service Modifications</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2">
            <li>We may modify, suspend, or discontinue any part of the Service at any time</li>
            <li>We will provide reasonable notice for significant changes</li>
            <li>Continued use after modifications constitutes acceptance of changes</li>
          </ul>
        </section>

        <!-- Limitation of Liability -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">10. Limitation of Liability</h2>
          <div class="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-700 rounded-lg p-4 mb-4">
            <p class="text-red-800 dark:text-red-200 font-medium">
              <strong>Important Legal Notice:</strong> Please read this section carefully as it limits our liability to you.
            </p>
          </div>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2 mb-4">
            <li>THE SERVICE IS PROVIDED "AS IS" WITHOUT WARRANTIES OF ANY KIND</li>
            <li>WE DISCLAIM ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE</li>
            <li>WE ARE NOT LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, OR CONSEQUENTIAL DAMAGES</li>
            <li>OUR TOTAL LIABILITY SHALL NOT EXCEED THE AMOUNT YOU PAID FOR THE SERVICE IN THE 12 MONTHS PRECEDING THE CLAIM</li>
            <li>WE ARE NOT RESPONSIBLE FOR DAMAGES RESULTING FROM AI DIAGNOSIS RECOMMENDATIONS</li>
          </ul>
        </section>

        <!-- Indemnification -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">11. Indemnification</h2>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed">
            You agree to indemnify and hold harmless CarWise.ai and its officers, directors, employees, and agents from any claims, damages, losses, or expenses (including attorney's fees) arising from your use of the Service, violation of these Terms, or infringement of any rights of another party.
          </p>
        </section>

        <!-- Termination -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">12. Termination</h2>
          
          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">12.1 Termination by You</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2 mb-4">
            <li>You may terminate your account at any time through your account settings</li>
            <li>Termination does not relieve you of obligations incurred before termination</li>
            <li>Some provisions of these Terms survive termination</li>
          </ul>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">12.2 Termination by Us</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2">
            <li>We may suspend or terminate your account for violations of these Terms</li>
            <li>We may discontinue the Service with reasonable notice</li>
            <li>We reserve the right to refuse service to anyone</li>
          </ul>
        </section>

        <!-- Governing Law -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">13. Governing Law and Dispute Resolution</h2>
          
          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">13.1 Governing Law</h3>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed mb-4">
            These Terms are governed by and construed in accordance with the laws of [Your Jurisdiction], without regard to conflict of law principles.
          </p>

          <h3 class="text-xl font-medium text-secondary-800 dark:text-secondary-200 mb-3">13.2 Dispute Resolution</h3>
          <ul class="list-disc list-inside text-secondary-700 dark:text-secondary-300 space-y-2">
            <li>We encourage resolution of disputes through direct communication</li>
            <li>Disputes may be resolved through binding arbitration</li>
            <li>Class action waivers may apply as permitted by law</li>
            <li>Some jurisdictions may not allow certain limitations</li>
          </ul>
        </section>

        <!-- Changes to Terms -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">14. Changes to Terms</h2>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed">
            We may update these Terms from time to time. We will notify you of material changes by posting the new Terms on our website and updating the "Last updated" date. Your continued use of the Service after such changes constitutes acceptance of the updated Terms.
          </p>
        </section>

        <!-- Contact Information -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">15. Contact Information</h2>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed mb-4">
            If you have any questions about these Terms of Service, please contact us:
          </p>
          <div class="bg-secondary-50 dark:bg-secondary-700/50 rounded-lg p-4">
            <p class="text-secondary-700 dark:text-secondary-300"><strong>Email:</strong> legal@carwise.ai</p>
            <p class="text-secondary-700 dark:text-secondary-300"><strong>Address:</strong> CarWise.ai Legal Department, [Your Business Address]</p>
            <p class="text-secondary-700 dark:text-secondary-300"><strong>Phone:</strong> [Your Contact Number]</p>
          </div>
        </section>

        <!-- Severability -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">16. Severability</h2>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed">
            If any provision of these Terms is found to be unenforceable or invalid, that provision will be limited or eliminated to the minimum extent necessary so that the remaining Terms will remain in full force and effect.
          </p>
        </section>

        <!-- Entire Agreement -->
        <section class="mb-8">
          <h2 class="text-2xl font-semibold text-secondary-900 dark:text-white mb-4">17. Entire Agreement</h2>
          <p class="text-secondary-700 dark:text-secondary-300 leading-relaxed">
            These Terms, together with our Privacy Policy and any other legal notices published by us on the Service, constitute the entire agreement between you and CarWise.ai concerning the Service.
          </p>
        </section>

      </div>
    </div>
  </div>
</template>

<script>
import { useRouter } from 'vue-router'

export default {
  name: 'TermsOfService',
  setup() {
    const router = useRouter()
    const lastUpdated = 'December 2024'

    const goBack = () => {
      router.go(-1)
    }

    return {
      lastUpdated,
      goBack
    }
  }
}
</script>
